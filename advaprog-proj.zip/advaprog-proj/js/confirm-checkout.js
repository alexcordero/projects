function getAddress() {
  document.getElementById('address').innerHTML = sessionStorage.getItem(address);
}
