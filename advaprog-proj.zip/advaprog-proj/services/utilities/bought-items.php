<?php
    @$_SESSION['selectedProductBuy'] = $_POST['buy'];
 ?>
