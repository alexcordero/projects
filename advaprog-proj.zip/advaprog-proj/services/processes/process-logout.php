<?php
     session_start();
     session_destroy();
     header ('location: ../../website/Landing-page.php');
?>
